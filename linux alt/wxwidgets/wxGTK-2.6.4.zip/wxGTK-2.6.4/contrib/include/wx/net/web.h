/////////////////////////////////////////////////////////////////////////////
// Name:        web.h
// Purpose:     wxWeb: portable web browser-related class
// Author:      Julian Smart
// Modified by:
// Created:     2001-08-21
// RCS-ID:      $Id: web.h,v 1.2 2002/09/07 12:10:20 GD Exp $
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "web.h"
#endif

#ifndef _WX_WEB_H_
#define _WX_WEB_H_

/*
 * wxWeb
 * Miscellaneous web functions
 */

class wxWeb
{
public:
//// Ctor/dtor
    wxWeb() {};

//// Operations

protected:
};


#endif //_WX_WEB_H_

